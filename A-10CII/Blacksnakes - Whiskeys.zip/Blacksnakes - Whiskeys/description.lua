livery = {
	{"A-10C_PAINT_1-a", 	0 ,"../../A-10C/Blacksnakes - Whiskeys/A-10C_163_1-a"		,false};
	{"A-10C_PAINT_1-b", 	0 ,"../../A-10C/Blacksnakes - Gunfighter/A-10C_163_1-b"		,false};
	{"A-10C_PAINT_1-c", 	0 ,"../../A-10C/Blacksnakes - Gunfighter/A-10C_163_1-c"		,false};
	{"A-10C_PAINT_1-d", 	0 ,"../../A-10C/Blacksnakes - Gunfighter/A-10C_163_1-d"		,false};
	{"A-10C_PAINT_1-e", 	0 ,"../../A-10C/Blacksnakes - Gunfighter/A-10C_163_1-e"		,false};
	{"A-10C_PAINT_1-f", 	0 ,"../../A-10C/Blacksnakes - Gunfighter/A-10C_163_1-f"		,false};
	{"A-10C_PAINT_1-g", 	0 ,"../../A-10C/Blacksnakes - Gunfighter/A-10C_163_1-g"		,false};
	{"A-10C_PAINT_1-h", 	0 ,"../../A-10C/Blacksnakes - Gunfighter/A-10C_163_1-h"		,false};
	{"A-10C_PAINT_1-i", 	0 ,"../../A-10C/Blacksnakes - Gunfighter/A-10C_163_1-i"		,false};
	{"A-10C_PAINT_1-j", 	0 ,"../../A-10C/Blacksnakes - Gunfighter/A-10C_163_1-j"		,false};
	{"A-10C_PAINT_1-k", 	0 ,"../../A-10C/Blacksnakes - Gunfighter/A-10C_163_1-k"		,false};
	{"A-10C_PAINT_1-L", 	0 ,"../../A-10C/Blacksnakes - Gunfighter/A-10C_163_1-L"		,false};
	{"A-10_Number", 		0 ,"../../A-10C/Blacksnakes - Gunfighter/tactnumbers-empty"	,false};
	{"A-10_Number", 		0 ,"../../A-10C/Blacksnakes - Gunfighter/tactnumbers-empty"	,false};
	{"A-10_Number_Noze_T", 	0 ,"../../A-10C/Blacksnakes - Gunfighter/tactnumbers-empty"	,false};
	{"A-10_Number_Noze_F", 	0 ,"../../A-10C/Blacksnakes - Gunfighter/tactnumbers-empty"	,false};	
	{"A-10_Number_Wheel", 	0 ,"../../A-10C/Blacksnakes - Gunfighter/tactnumbers-empty"	,false};
	--{"A-10_Number", 		ROUGHNESS_METALLIC ,"tactnumbers-usaf_RoughMet"	,false};
	--{"A-10_Number_Noze_T", 	0 ,"tactnumbers-usaf"	,false};
	--{"A-10_Number_Noze_T", 	ROUGHNESS_METALLIC ,"tactnumbers-usaf_RoughMet"	,false};
	--{"A-10_Number_Noze_F", 	0 ,"tactnumbers-empty"	,false};	
	--{"A-10_Number_Wheel", 	0 ,"tactnumbers-usaf"	,false};
	--{"A-10_Number_Wheel", 	ROUGHNESS_METALLIC ,"tactnumbers-usaf_RoughMet"	,false};
	{"pilot_A10",	DIFFUSE			,	"../../A-10C/Blacksnakes - Gunfighter/pilot_a10c", false};
	--{"pilot_A10",	NORMAL_MAP			,	"pilot_a10c_nm", false};
	--{"pilot_A10",	SPECULAR			,	"pilot_a10c_roughmet", false};
	--{"pilot_A10_helmet",	DIFFUSE			,	"pilot_a10_helmet", false};
	--{"pilot_A10_helmet",	NORMAL_MAP			,	"pilot_a10_helmet_nm", false};
	--{"pilot_A10_helmet",	SPECULAR			,	"pilot_a10_helmet_roughmet", false};

}
name = "Blacksnakes - Whiskeys"
--Skin made by Whisky.Actual